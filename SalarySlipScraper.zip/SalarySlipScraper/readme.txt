使用方法

1.settings.jsonにIDとpassを記入(設定しなくても使用できるが都度手動でのログインが必要)
2.SalarySlipScraper.exeを実行、暫く待つ
3.SalarySlip.csvが生成されたら完了


改訂履歴

2024/12/25 1.0.0
初回リリース